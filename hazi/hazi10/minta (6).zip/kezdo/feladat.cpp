#include <iostream>
#include <string>

using namespace std;

class Konyvtar;

class FRElem {
protected:
  string nev;
  Konyvtar *szulo;

  FRElem(const string& nev, Konyvtar* szulo) :
    nev(nev), szulo(szulo) { }
  
public:
  const string& getNev() const {
    return nev;
  }
  
  const Konyvtar* getSzulo() const noexcept {
    return szulo;
  }

  string getTeljesUtvonal() const;
};


#ifndef TEST_BIRO

int main() {
#if 0
  Konyvtar& gyoker = Konyvtar::getGyoker();
  Konyvtar& k2 = gyoker / "elso" / "masodik";
  Konyvtar& k4 = k2 / "harmadik" / "negyedik";
  gyoker / "elso 2";
  gyoker / "elso 3";
  
  k2 % "readme.txt";
  k4 % "feladat.cpp";
  k4 / "otodik";

  cout << "Teljes utvonal" << endl;
  cout << k2.getTeljesUtvonal() << endl;
  cout << gyoker.getTeljesUtvonal() << endl;
  //  Teljes utvonal
  //  /elso/masodik/
  //  /

  cout << endl << "ls I." << endl;
  k2.ls();
  //  ls I.
  //  masodik
  //    harmadik
  //      negyedik
  //        feladat.cpp (fajl)
  //        otodik
  //    readme.txt (fajl)

  cout << endl << "ls II." << endl;
  gyoker.ls();
  //  ls II.
  //  /
  //    elso
  //      masodik
  //        harmadik
  //          negyedik
  //            feladat.cpp (fajl)
  //            otodik
  //        readme.txt (fajl)
  //    elso 2
  //    elso 3  
  
  cout << endl << "operator >>" << endl;
  Konyvtar& masodik = gyoker >> "elso" >> "masodik";
  cout << masodik.getNev() << endl;
  //  operator >>
  //  masodik

  cout << endl << "cp" << endl;
  gyoker.cp(k2);
  gyoker.ls();
  //  cp
  //  /
  //    elso
  //      masodik
  //        harmadik
  //          negyedik
  //            feladat.cpp (fajl)
  //            otodik
  //        readme.txt (fajl)
  //    elso 2
  //    elso 3
  //    masodik
  //      harmadik
  //        negyedik
  //          feladat.cpp (fajl)
  //          otodik
  //      readme.txt (fajl)
  
  cout << endl << "rm I." << endl;
  (gyoker >> "masodik").rm();
  gyoker.ls();
  //  rm I.
  //  /
  //    elso
  //      masodik
  //        harmadik
  //          negyedik
  //            feladat.cpp (fajl)
  //            otodik
  //        readme.txt (fajl)
  //    elso 2
  //    elso 3
  
  cout << endl << "rm II." << endl;
  gyoker.rm();
  gyoker.ls();
  //  rm II.
  //  /
#endif
}
#endif
