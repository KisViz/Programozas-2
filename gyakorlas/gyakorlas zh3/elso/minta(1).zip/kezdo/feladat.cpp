#include <string>
#include <iostream>
#include <vector>
using namespace std;


class Verseny {
protected:
  string nev;
public:
  Verseny(const string& n) : nev(n) { }
  
  string leiras() const {
    return nev;
  }
};

class FutoVerseny : public Verseny {
  unsigned tavolsag;

public:
  FutoVerseny(const string& nev, unsigned tav) : Verseny(nev), tavolsag(tav) { }

  unsigned getTavolsag() const noexcept {
    return tavolsag;
  }

  string leiras() const {
   return nev + " - " + to_string(tavolsag); 
  }
};

class HegymaszoVerseny : public Verseny {
  string hegy;

public:
  HegymaszoVerseny(const string& nev, const string& hegy) : Verseny(nev), hegy(hegy) { }

  string leiras() const {
    return nev + " - " + hegy; 
  }
};

#ifndef TEST_BIRO

int main() {
  /*
  Verseny* ub = new FutoVerseny("Ultra Balaton", 211);
  cout << ub->leiras() << endl;
  // Ultra Balaton - 211

  FutoVerseny* szegedm = new FutoVerseny("Szeged Maraton", 42);
  HegymaszoVerseny* kekes = new HegymaszoVerseny("Kekes Maszas", "Kekes");

  Versenyek v;
  v << ub << szegedm << kekes;
  v.kiir();
  // Ultra Balaton - 211
  // Szeged Maraton - 42
  // Kekes Maszas - Kekes
  
  {
    Versenyek v2(v);
    v2.kiir();
    // Ultra Balaton - 211
    // Szeged Maraton - 42
    // Kekes Maszas - Kekes
  }
  
  UltraFutoVersenyek ufv;
  ufv << new FutoVerseny("Szegedi Esti Kocogas", 10)
      << new FutoVerseny("Szeged-Budapest", 192)
      << new HegymaszoVerseny("Magas Tatra", "Tatra");
  // ketto objektum nem lesz felszabaditva, de ez most nem gond ...
  ufv.kiir();
  // Szeged-Budapest - 192

  ufv << v;
  ufv.kiir();
  // Ultra Balaton - 211
  // Szeged Maraton - 42
  */
}

#endif
