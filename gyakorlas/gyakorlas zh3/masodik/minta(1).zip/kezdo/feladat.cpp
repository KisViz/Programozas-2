#include <iostream>
using namespace std;


class Sikidom {
    const string tipus;
public:
    Sikidom(const string& tipus) : tipus(tipus){}
    virtual unsigned kerulet() const = 0;

    string keruletToString() const {
        return "A " + tipus + " kerulete " + to_string(kerulet()) + " egyseg.";
    }
};

int main() {
    /*
     //Beugro feladat
    Teglalap t(3,4);
    Negyzet n(5);
    Haromszog h(3,4,5);

    cout << t.keruletToString() << endl;

    //Rajz osztalytol
    Rajz rajz;

    //hozzaadas
    rajz << &t << &h;

    //kiiratas
    cout << rajz;

    //++ operator
    rajz++;
    cout << rajz;

    //Copy konstruktor
    cout << "Copy" <<endl;
    Rajz rajz2 = rajz;
    cout << rajz2;

    //Ertekado operator
    rajz=rajz2;
    cout << rajz << endl;
    */
    return 0;
}
