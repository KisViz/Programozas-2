#include <iostream>
#include <vector>

class Gyerek {
  int boldogsag = 0;
  string nev = "gyerek";
public:
  Gyerek() = default;

  Gyerek(const string& n) : nev(n) { }
  
  int getBoldogsag() const {
    return boldogsag;
  }

  Gyerek& setBoldogsag( int b ) {
    boldogsag = b;
    return *this;
  }
  
  const string& getNev() const {
    return nev;
  }
};


class Ajandek {
protected:
  string uzenet;
public:
  Ajandek(const string& u) : uzenet(u) { }

  void ajandekoz(Gyerek& gy) const {
    cout << uzenet << endl;
  }
};

class Vonat : public Ajandek {
  int boldogsag;
public:
  Vonat(const string& u, unsigned b) : Ajandek(u), boldogsag(b) { }

};

class Virgacs : public Ajandek {
public:
  Virgacs() : Ajandek("jaj") { }

};


#ifndef TEST_BIRO

int main() {
  Vonat mav( "MAV vonat", -10 );
  Vonat tgv( "TGV", 100 );
  Vonat kisvasut( "Kisvasut", 2 );
  Virgacs virgacs;
  
  Gyerek kisfiu;
  cout << kisfiu.getBoldogsag() << endl << endl;
  // 0
  
  mav.ajandekoz(kisfiu);
  cout << kisfiu.getBoldogsag() << endl << endl;
  // MAV vonat
  // -10
  // 100
  
  Mikulas miki;
  miki >> kisfiu;
  miki << mav << tgv << kisvasut;
  miki >> kisfiu;
  cout << kisfiu.getBoldogsag() << endl << endl;
  // Kisvasut
  // 2
  
  Mikulas m2;
  m2 << miki;
  m2 >> kisfiu;
  
  Gyerek gy2("..");
  m2 >> gy2;
  // TGV
}

#endif
